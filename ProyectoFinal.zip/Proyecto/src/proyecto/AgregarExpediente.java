/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto;

import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JOptionPane;
import static proyecto.RegistrarUsuario.agregarUsuario;
import static proyecto.RegistrarUsuario.verificarCredenciales;
/**
 *
 * @author cesar-rodriguez
 */
public class AgregarExpediente extends javax.swing.JFrame {
    private static final String URL = "jdbc:mysql://localhost:3306/proyecto";
    private static final String USER = "root";
    private static final String PASSWORD = "Goli@t2014";
    
    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    /**
     * Creates new form ControlExpedientes
     */
    public AgregarExpediente() {
        initComponents();
        Color miColor = new Color(222, 205, 164);
        getContentPane().setBackground(miColor);
        this.setLocationRelativeTo(null);
        llenarComboBoxPropietarios(jComboBox2);
        setDefaultCloseOperation(AgregarExpediente.DISPOSE_ON_CLOSE);
        llenarComboBoxEstado(estados);
        municipios.setEnabled(false);
        fecha1.getDateEditor().getUiComponent().setEnabled(false);
        fecha2.getDateEditor().getUiComponent().setEnabled(false);
        fecha3.getDateEditor().getUiComponent().setEnabled(false);
        jPanel1.setBackground(miColor);
        jPanel3.setBackground(miColor);
        jPanel4.setBackground(miColor);
        jPanel6.setBackground(miColor);
    }
    
    public void refresh() {
        this.dispose();          // Libera recursos
        AgregarExpediente refresh = new AgregarExpediente();
        refresh.setVisible(true);
}
    
    public int busquedaExpediente(String [] propietario){

        if(propietario.length== 3){
            return obtenerIdPropietario(propietario[0], propietario[1], propietario[2]);
        }else if(propietario.length == 4){
            String nombrePropietario = propietario[0] + " " + propietario[1];
            return obtenerIdPropietario(nombrePropietario, propietario[2], propietario[3]);
        }
        return -2;
    }
    
    public static int obtenerIdPropietario(String nombre, String apellidoPaterno, String apellidoMaterno) {
        
        // Consulta SQL para buscar el propietario
        String sql = "SELECT idPropietarios FROM propietarios WHERE Nombre = ? AND Paterno = ? AND Materno = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Asignar valores a los parámetros de la consulta
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellidoPaterno);
            pstmt.setString(3, apellidoMaterno);
            
            // Ejecutar la consulta
            ResultSet rs = pstmt.executeQuery();
            
            // Si hay un resultado, devolver el ID del propietario
            if (rs.next()) {
                return rs.getInt("idPropietarios");
            } else {
                return -1; // Retorna -1 si no se encuentra el propietario
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Retorna -1 en caso de error
        }
    }
    
    public boolean insertarExpediente(int idPropietario, String noLote, String superficie, String calle, String numero, String colonia, String municipio, String estado, java.sql.Date fechaCV, java.sql.Date fechaIO, java.sql.Date fechaFO) {
        String sql = "INSERT INTO expediente (idPropietarios, Numero_Lote, Superficie, Calle, Numero, Colonia, Municipio, Estado, Fecha_compra_venta, Inicio_de_obra, Termino_de_obra) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, idPropietario + "");
            pstmt.setString(2, noLote);
            pstmt.setString(3, superficie);
            pstmt.setString(4, calle);
            pstmt.setString(5, numero);
            pstmt.setString(6, colonia);
            pstmt.setString(7, municipio);
            pstmt.setString(8, estado);
            pstmt.setString(9, fechaCV.toString());
            pstmt.setString(10, fechaIO.toString());
            pstmt.setString(11, fechaFO.toString());

            int filasInsertadas = pstmt.executeUpdate();
            if (filasInsertadas > 0) {
                JOptionPane.showMessageDialog(null, "Expediente registrado correctamente");
                refresh();
                return true;
            }
        } catch (SQLException e) {
            //e.printStackTrace();
            return false;
        }
        return false;
    }
    
    public void llenarComboBoxPropietarios(JComboBox<String> comboBox) {
        String consulta = "SELECT Nombre, Paterno, Materno FROM propietarios";  // Modifica con tu tabla y columna

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery(consulta)) {
            
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione propietario");
            while (rs.next()) {
               comboBox.addItem(rs.getString("Nombre") + " " + rs.getString("Paterno") + " "+ rs.getString("Materno")); // Agregar cada nombre al ComboBox 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void llenarComboBoxEstado(JComboBox<String> comboBox) {
        String consulta = "SELECT id_estado, nombre FROM estados";  // Modifica con tu tabla y columna

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery(consulta)) {
            
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione estado");
            while (rs.next()) {
               comboBox.addItem(rs.getString("id_estado") + " " + rs.getString("nombre")); // Agregar cada nombre al ComboBox 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void llenarComboBoxMunicipio(JComboBox<String> comboBox, String id) {
        String consulta = "SELECT id_municipio, nombre FROM municipios WHERE id_estado = ?";  

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        
        pstmt.setString(1, id);  // Asigna correctamente el ID

        try (ResultSet rs = pstmt.executeQuery()) {  // Ejecuta la consulta correctamente
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione municipio");

            while (rs.next()) {
                String municipio = rs.getString("id_municipio") + " " + 
                                    rs.getString("nombre");
                comboBox.addItem(municipio);  // Agrega cada expediente al ComboBox 
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }
    
    public void llenarComboBoxExpedientes(JComboBox<String> comboBox, int id) {
    String consulta = "SELECT Numero_Lote, Colonia, Calle, Numero, Municipio, Estado FROM expedientes WHERE idExpediente = ?";  

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        
        pstmt.setInt(1, id);  // Asigna correctamente el ID

        try (ResultSet rs = pstmt.executeQuery()) {  // Ejecuta la consulta correctamente
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione expediente");

            while (rs.next()) {
                String expediente = rs.getString("Numero_Lote") + " " + 
                                    rs.getString("Colonia") + " " + 
                                    rs.getString("Calle") + " " + 
                                    rs.getString("Numero") + " " + 
                                    rs.getString("Estado") + " " + 
                                    rs.getString("Municipio");
                comboBox.addItem(expediente);  // Agrega cada expediente al ComboBox 
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        calle = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        numero = new javax.swing.JTextField();
        colonia = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        estados = new javax.swing.JComboBox<>();
        municipios = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        noLote = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        fecha1 = new com.toedter.calendar.JDateChooser();
        fecha2 = new com.toedter.calendar.JDateChooser();
        fecha3 = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        superficie = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1100, 850));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Agregar expediente", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Propietario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jComboBox2.setBackground(new java.awt.Color(0, 0, 0, 0));
        jComboBox2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jButton1.setBackground(new java.awt.Color(153, 255, 153));
        jButton1.setText("Agregar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Ubicacion", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        calle.setForeground(new java.awt.Color(153, 153, 153));
        calle.setText("Calle");
        calle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                calleFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                calleFocusLost(evt);
            }
        });
        calle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calleActionPerformed(evt);
            }
        });
        calle.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                calleKeyTyped(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/la-carretera.png"))); // NOI18N

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/hashtag.png"))); // NOI18N

        numero.setForeground(new java.awt.Color(153, 153, 153));
        numero.setText("Numero");
        numero.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                numeroFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                numeroFocusLost(evt);
            }
        });
        numero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numeroActionPerformed(evt);
            }
        });
        numero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numeroKeyTyped(evt);
            }
        });

        colonia.setForeground(new java.awt.Color(153, 153, 153));
        colonia.setText("Colonia");
        colonia.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                coloniaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                coloniaFocusLost(evt);
            }
        });
        colonia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coloniaActionPerformed(evt);
            }
        });
        colonia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                coloniaKeyTyped(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ubicacion.png"))); // NOI18N

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ubicacion.png"))); // NOI18N

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ubicacion.png"))); // NOI18N

        estados.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        estados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estadosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(numero, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(calle, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(colonia)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(estados, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(municipios, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(21, 21, 21))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(calle, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(estados, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(numero, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addComponent(colonia, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(municipios, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Informacion", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calendario.png"))); // NOI18N

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calendario.png"))); // NOI18N

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calendario.png"))); // NOI18N

        noLote.setForeground(new java.awt.Color(153, 153, 153));
        noLote.setText("No de lote");
        noLote.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                noLoteFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                noLoteFocusLost(evt);
            }
        });
        noLote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noLoteActionPerformed(evt);
            }
        });
        noLote.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                noLoteKeyTyped(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/hashtag.png"))); // NOI18N

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pantalla-completa.png"))); // NOI18N

        fecha2.setToolTipText("");

        jLabel1.setText("Fecha Compra-Venta");

        jLabel2.setText("Fecha Inicio Obra");

        jLabel10.setText("Fecha Fin Obra");

        superficie.setForeground(new java.awt.Color(153, 153, 153));
        superficie.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Superficie", "500", "1000", "1500", "2000" }));
        superficie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                superficieActionPerformed(evt);
            }
        });

        jLabel11.setText("m2");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fecha1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel1))
                            .addComponent(noLote, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addComponent(jLabel14)
                            .addComponent(jLabel4))
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fecha3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(fecha2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addComponent(superficie, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel11)
                                        .addGap(0, 6, Short.MAX_VALUE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel10)
                                .addGap(56, 56, 56)))
                        .addGap(10, 10, 10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(55, 55, 55))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(noLote, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(superficie, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel11)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(fecha1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(fecha2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fecha3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(36, 36, 36)
                        .addComponent(jLabel14)
                        .addGap(36, 36, 36)
                        .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        jButton2.setBackground(new java.awt.Color(255, 102, 102));
        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void noLoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noLoteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_noLoteActionPerformed

    private void calleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_calleActionPerformed

    private void numeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numeroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numeroActionPerformed

    private void coloniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_coloniaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_coloniaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Date fechaCompraVenta = fecha1.getDate();
        Date fechaInicioObra = fecha2.getDate();
        Date fechaFinObra = fecha3.getDate();
        
            
        
        if(fechaCompraVenta != null && fechaInicioObra != null && fechaFinObra != null){
            
            long fechaCV = fechaCompraVenta.getTime();
        java.sql.Date fechaCV_sql = new java.sql.Date(fechaCV);
        
        
        long fechaIO = fechaInicioObra.getTime();
        java.sql.Date fechaIO_sql = new java.sql.Date(fechaIO);
        
        
        long fechaFO = fechaFinObra.getTime();
        java.sql.Date fechaFO_sql = new java.sql.Date(fechaFO);
        if(fechaCV_sql.before(fechaIO_sql) && fechaCV_sql.before(fechaFO_sql) && fechaIO_sql.before(fechaFO_sql)){
        
        String [] propietarioDiv = jComboBox2.getSelectedItem().toString().split(" ");
        //busquedaExpediente(propietarioDiv);
        //System.out.println(busquedaExpediente(propietarioDiv));
        
        if(!jComboBox2.getSelectedItem().equals("Seleccione propietario") && 
                !calle.getText().isEmpty() && !calle.getText().equals("Calle") && 
                !numero.getText().isEmpty() && !numero.getText().equals("Numero") && 
                !colonia.getText().isEmpty() && !colonia.getText().equals("Colonia") && 
                !municipios.getSelectedItem().equals("Seleccione municipio") && 
                !estados.getSelectedItem().equals("Seleccione estado") && 
                !noLote.getText().isEmpty() && 
                !noLote.getText().equals("No de lote") && 
                !superficie.getSelectedItem().equals("superficie") && 
                fecha1 != null && fecha2 != null && fecha3 != null){
           if(insertarExpediente(busquedaExpediente(propietarioDiv), noLote.getText(), superficie.getSelectedItem().toString(), calle.getText(), numero.getText(), colonia.getText(), municipios.getSelectedItem().toString().split(" ")[1], estados.getSelectedItem().toString().split(" ")[1], fechaCV_sql, fechaIO_sql, fechaFO_sql)) {
            //JOptionPane.showMessageDialog(null, "Expediente registrado correctamente");
            //limpiarCampos();
        }else{
            JOptionPane.showMessageDialog(null, "Error en el registro del expediente");
        }
        }else{
            JOptionPane.showMessageDialog(null, "❌Todos los campos deben estar llenos");
        }
        }else{
            JOptionPane.showMessageDialog(null, "❌Fechas invalidas, verifique los campos");
        }
        }else{
            JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        jComboBox2.repaint();
        jComboBox2.revalidate();
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void calleKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_calleKeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9') && (c<'a' || c>'z') && (c<'A'||c>'Z') && c != ' ')evt.consume();
        
        //Limitacion de 16 caracteres
        if(calle.getText().length() >= 16)evt.consume();
        
        if (Character.isLetterOrDigit(c) || evt.getKeyChar() == KeyEvent.VK_SPACE || evt.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
        //Codigo
        String cad = ("" + c).toUpperCase();
        c = cad.charAt(0);
        evt.setKeyChar(c);
    }
    }//GEN-LAST:event_calleKeyTyped

    private void numeroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numeroKeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
        
        //Limitacion de 8 caracteres
        if(numero.getText().length() >= 8)evt.consume();
    }//GEN-LAST:event_numeroKeyTyped

    private void coloniaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_coloniaKeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9') && (c<'a' || c>'z') && (c<'A'||c>'Z') && c != ' ')evt.consume();
        
        //Limitacion de 16 caracteres
        if(colonia.getText().length() >= 16)evt.consume();
        
        if (Character.isLetterOrDigit(c) || evt.getKeyChar() == KeyEvent.VK_SPACE || evt.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
        //Codigo
        String cad = ("" + c).toUpperCase();
        c = cad.charAt(0);
        evt.setKeyChar(c);
    }
    }//GEN-LAST:event_coloniaKeyTyped

    private void noLoteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_noLoteKeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
        
        //Limitacion de 8 caracteres
        if(noLote.getText().length() >= 5)evt.consume();
    }//GEN-LAST:event_noLoteKeyTyped

    private void calleFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_calleFocusGained
        if (calle.getText().equals("Calle")) {
            calle.setText("");
            calle.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_calleFocusGained

    private void calleFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_calleFocusLost
        if (calle.getText().isEmpty()) {
            calle.setText("Calle");
            calle.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_calleFocusLost

    private void numeroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_numeroFocusGained
        if (numero.getText().equals("Numero")) {
            numero.setText("");
            numero.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_numeroFocusGained

    private void numeroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_numeroFocusLost
        if (numero.getText().isEmpty()) {
            numero.setText("Numero");
            numero.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_numeroFocusLost

    private void coloniaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_coloniaFocusGained
        if (colonia.getText().equals("Colonia")) {
            colonia.setText("");
            colonia.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_coloniaFocusGained

    private void coloniaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_coloniaFocusLost
        if (colonia.getText().isEmpty()) {
            colonia.setText("Colonia");
            colonia.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_coloniaFocusLost

    private void noLoteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_noLoteFocusGained
        if (noLote.getText().equals("No de lote")) {
            noLote.setText("");
            noLote.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_noLoteFocusGained

    private void noLoteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_noLoteFocusLost
        if (noLote.getText().isEmpty()) {
            noLote.setText("No de lote");
            noLote.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_noLoteFocusLost

    private void superficieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_superficieActionPerformed
        
    }//GEN-LAST:event_superficieActionPerformed

    private void estadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estadosActionPerformed
       if (estados.getSelectedItem() != null) {
           municipios.setEnabled(true);
           if(!estados.getSelectedItem().toString().equals("Seleccione estado")){
               //Cambiar a editable
               String[] contenido = estados.getSelectedItem().toString().split(" ");
    llenarComboBoxMunicipio(municipios, contenido[0]);
           }
    
} else {
    //System.out.println("No se ha seleccionado ningún estado.");
}
        
        
    }//GEN-LAST:event_estadosActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgregarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgregarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgregarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgregarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregarExpediente().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField calle;
    private javax.swing.JTextField colonia;
    private javax.swing.JComboBox<String> estados;
    private com.toedter.calendar.JDateChooser fecha1;
    private com.toedter.calendar.JDateChooser fecha2;
    private com.toedter.calendar.JDateChooser fecha3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JComboBox<String> municipios;
    private javax.swing.JTextField noLote;
    private javax.swing.JTextField numero;
    private javax.swing.JComboBox<String> superficie;
    // End of variables declaration//GEN-END:variables
}
