/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author cesar-rodriguez
 */
class MultiLineRenderer extends JLabel implements ListCellRenderer<Object> {
    Color miColor = new Color(222, 205, 164);
    public MultiLineRenderer() {
        setBackground(miColor);
        setOpaque(true);
    }

    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        if (value != null) {
            // Reemplaza \n con <br> para mostrar múltiples líneas
            setText("<html>" + value.toString().replace("\n", "<br>") + "</html>");
        } else {
            setText("");
        }

        // Manejo de colores cuando se selecciona un elemento
        if (isSelected) {
            setBackground(miColor);
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(miColor);
            setForeground(list.getForeground());
        }

        return this;
    }
}