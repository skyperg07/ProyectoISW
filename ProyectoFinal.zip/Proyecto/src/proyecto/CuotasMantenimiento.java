/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import static proyecto.AgregarExpediente.getConnection;

/**
 *
 * @author cesar-rodriguez
 */
public class CuotasMantenimiento extends javax.swing.JFrame {
    
    
    String idExpediente;
    Color miColor = new Color(222, 205, 164);
    LocalDate fecha = LocalDate.now();

    /**
     * Creates new form EditarExpediente
     */
    public CuotasMantenimiento() {
        initComponents();
        this.setLocationRelativeTo(null);
        getContentPane().setBackground(miColor);
        setDefaultCloseOperation(RegistrarUsuario.DISPOSE_ON_CLOSE);
        llenarComboBoxPropietarios(jComboBox3);
        jPanel2.setBackground(miColor);
        jPanel5.setBackground(miColor);
        jPanel9.setBackground(miColor);
        jPanel7.setBackground(miColor);
        jLabel2.setText("Fecha de hoy: " + fecha.toString());
    }
    
    public void refresh() {
        this.dispose();          // Libera recursos
        CuotasMantenimiento refresh = new CuotasMantenimiento();
        refresh.setVisible(true);
}
    
    
        public boolean editarExpediente(String idExpediente, int idPropietario, String noLote, String superficie, String calle, String numero, String colonia, String municipio, String estado, java.sql.Date fechaCV, java.sql.Date fechaIO, java.sql.Date fechaFO) {
        String sql = "UPDATE expediente SET idPropietarios = ?, Numero_Lote = ?, Superficie = ?, Calle = ?, Numero = ?, Colonia = ?, Municipio = ?, Estado = ?, Fecha_compra_venta = ?, Inicio_de_obra = ?, Termino_de_obra = ? WHERE idExpediente = ?;";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, idPropietario + "");
            pstmt.setString(2, noLote.toUpperCase());
            pstmt.setString(3, superficie.toUpperCase());
            pstmt.setString(4, calle.toUpperCase());
            pstmt.setString(5, numero);
            pstmt.setString(6, colonia.toUpperCase());
            pstmt.setString(7, municipio.toUpperCase());
            pstmt.setString(8, estado.toUpperCase());
            pstmt.setString(9, fechaCV.toString());
            pstmt.setString(10, fechaIO.toString());
            pstmt.setString(11, fechaFO.toString());
            pstmt.setString(12, idExpediente);

            int filasInsertadas = pstmt.executeUpdate();
            if (filasInsertadas > 0) {
                //System.out.println("Expediente modificado correctamente");
                JOptionPane.showMessageDialog(null, "Expediente modificado correctamente");
                refresh();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }
        
        public boolean insertarPago(String idExpediente, String tarifa, LocalDate fecha) {
        String sql = "INSERT INTO cuota_de_mantenimiento (idExpediente, Tarifa, Fecha_de_Pago) VALUES (?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, idExpediente + "");
            pstmt.setString(2, tarifa);
            pstmt.setString(3, fecha.toString());

            int filasInsertadas = pstmt.executeUpdate();
            if (filasInsertadas > 0) {
                JOptionPane.showMessageDialog(null, "Pago de cuota agregado correctamente");
                refresh();
                return true;
            }
        } catch (SQLException e) {
            //e.printStackTrace();
            return false;
        }
        return false;
    }
        
    
    public int busquedaExpediente(String [] propietario){

        if(propietario.length== 3){
            return obtenerIdPropietario(propietario[0], propietario[1], propietario[2]);
        }else if(propietario.length == 4){
            String nombrePropietario = propietario[0] + " " + propietario[1];
            return obtenerIdPropietario(nombrePropietario, propietario[2], propietario[3]);
        }
        return -2;
    }
    
    public static int obtenerIdPropietario(String nombre, String apellidoPaterno, String apellidoMaterno) {
        
        // Consulta SQL para buscar el propietario
        String sql = "SELECT idPropietarios FROM propietarios WHERE Nombre = ? AND Paterno = ? AND Materno = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Asignar valores a los parámetros de la consulta
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellidoPaterno);
            pstmt.setString(3, apellidoMaterno);
            
            // Ejecutar la consulta
            ResultSet rs = pstmt.executeQuery();
            
            // Si hay un resultado, devolver el ID del propietario
            if (rs.next()) {
                return rs.getInt("idPropietarios");
            } else {
                return -1; // Retorna -1 si no se encuentra el propietario
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Retorna -1 en caso de error
        }
    }
    
    public void llenarComboBoxPropietarios(JComboBox<String> comboBox) {
        String consulta = "SELECT Nombre, Paterno, Materno FROM propietarios";  // Modifica con tu tabla y columna

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery(consulta)) {
            
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione propietario");
            while (rs.next()) {
               comboBox.addItem(rs.getString("Nombre") + " " + rs.getString("Paterno") + " "+ rs.getString("Materno")); // Agregar cada nombre al ComboBox 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void llenarComboBoxExpedientes(JComboBox<String> comboBox, int id) {
    String consulta = "SELECT idExpediente, Numero_Lote, Colonia, Calle, Numero, Municipio, Estado, Fecha_compra_venta FROM expediente WHERE idPropietarios = ?";  

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        
        pstmt.setInt(1, id);  // Asigna correctamente el ID

        try (ResultSet rs = pstmt.executeQuery()) {  // Ejecuta la consulta correctamente
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione expediente");

            while (rs.next()) {
                String expediente = "Folio: " + rs.getString("idExpediente") + "\n" + " " + 
                        "Numero de lote: " + rs.getString("Numero_Lote") + " " + 
                        "Colonia: " + rs.getString("Colonia") + " " + 
                        "Calle: " + rs.getString("Calle") + "\n" + 
                        "Numero: " + rs.getString("Numero") + " " + 
                        "Estado: " + rs.getString("Estado") + " " + 
                        "Municipio: " + rs.getString("Municipio") + "\n" +
                        "Fecha Compra-Venta: " + rs.getDate("Fecha_compra_venta");
                
                comboBox.addItem(expediente);  // Agrega cada expediente al ComboBox 
            }
            
             // Establecer tamaño fijo(Error solucionado pero buscar mejor opcion)
        Dimension fixedSize = new Dimension(150, 30);
        comboBox.setPreferredSize(fixedSize);
        comboBox.setMinimumSize(fixedSize);
        comboBox.setMaximumSize(fixedSize);

            comboBox.setRenderer(new MultiLineRenderer());
//            jPanel2.setBackground(miColor);
//            jPanel5.setBackground(miColor);
//            jPanel9.setBackground(miColor);
//            jPanel7.setBackground(miColor);
//            jPanel8.setBackground(miColor);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        
    }
}
    
    
    
public int obtenerIdExpediente(String numeroLote, Double superficie, String calle, String numero, String colonia, String estado, String municipio, java.sql.Date fechaCV, java.sql.Date fechaIO, java.sql.Date fechaFO) {
    String consulta = "SELECT idExpediente FROM expediente WHERE Numero_Lote = ? AND Superficie = ? AND Calle = ? AND Numero = ? AND Colonia = ? AND Municipio = ? AND Estado = ? AND Fecha_Compra_Venta = ? AND Inicio_de_obra = ? AND Termino_de_obra = ?";
    int idExpediente = -1; // Valor predeterminado si no se encuentra el expediente

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {

        // Establecer los parámetros de la consulta
        pstmt.setString(1, numeroLote);
        pstmt.setDouble(2, superficie);
        pstmt.setString(3, calle);
        pstmt.setString(4, numero);
        pstmt.setString(5, colonia);
        pstmt.setString(6, estado);
        pstmt.setString(7, municipio);
        pstmt.setDate(8, fechaCV);
        pstmt.setDate(9, fechaIO);
        pstmt.setDate(10, fechaFO);

        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                // Si se encuentra el expediente, obtener el id
                idExpediente = rs.getInt("idExpediente");
            } else {
                // Si no se encuentra, mostrar mensaje
                JOptionPane.showMessageDialog(null, "No se encontró el expediente con los datos proporcionados", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener el ID del expediente: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    return idExpediente;
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        cantidad = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Cuotas de Mantenimiento", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jPanel5.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Propietario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jComboBox3.setBackground(new java.awt.Color(0, 0, 0, 0));
        jComboBox3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jButton2.setBackground(new java.awt.Color(153, 255, 153));
        jButton2.setText("Aceptar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Cantidad", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/dinero-en-efectivo.png"))); // NOI18N

        cantidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ingrese cantidad...", "500", "1000", "2000" }));

        jLabel2.setText("FECHA");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(92, 92, 92)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2))
                    .addComponent(jLabel12))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Expediente", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jComboBox4.setBackground(new java.awt.Color(0, 0, 0, 0));
        jComboBox4.setToolTipText("");
        jComboBox4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jComboBox4.setPreferredSize(new java.awt.Dimension(496, 29));
        jComboBox4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jComboBox4MousePressed(evt);
            }
        });
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jComboBox4, javax.swing.GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton3.setBackground(new java.awt.Color(255, 102, 102));
        jButton3.setText("Cancelar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton2))
                .addGap(254, 254, 254))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        String [] propietarioDiv = jComboBox3.getSelectedItem().toString().split(" ");
        llenarComboBoxExpedientes(jComboBox4, busquedaExpediente(propietarioDiv));
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        if((jComboBox4.getSelectedItem().toString().equals("Seleccione expediente")) || (jComboBox3.getSelectedItem().toString().equals("Seleccione propietario"))){
            JOptionPane.showMessageDialog(null, "Seleccione propietario y/o expediente");
        }else{
           String [] expediente = jComboBox4.getSelectedItem().toString().split(" ");
           idExpediente = expediente[1];
        }
               
        
        String [] propietarioDiv = jComboBox3.getSelectedItem().toString().split(" ");
        //busquedaExpediente(propietarioDiv);
        //System.out.println(busquedaExpediente(propietarioDiv));
        
        if(!jComboBox4.getSelectedItem().equals("Seleccione expediente") && 
                !cantidad.getSelectedItem().equals("Ingrese cantidad...")){
                fecha = LocalDate.now();
           if(insertarPago(idExpediente, cantidad.getSelectedItem().toString(), fecha)) {
            //JOptionPane.showMessageDialog(null, "Expediente modificado correctamente");
            //limpiarCampos();
        }else{
            JOptionPane.showMessageDialog(null, "Error en la edicion del expediente");
        }
        }else{
            JOptionPane.showMessageDialog(null, "❌Todos los campos deben estar llenos");
        }
        
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
//        if(!jComboBox4.getSelectedItem().equals("Seleccione expediente") && jComboBox4.getSelectedItem().equals(null)){
//            String seleccionado = (String) jComboBox4.getSelectedItem();
//        System.out.println(seleccionado);
//        idExpediente = seleccionado.split(" ")[1];
//        System.out.println(idExpediente);
//        }
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox4MousePressed
       
    }//GEN-LAST:event_jComboBox4MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CuotasMantenimiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CuotasMantenimiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CuotasMantenimiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CuotasMantenimiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CuotasMantenimiento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cantidad;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    // End of variables declaration//GEN-END:variables
}
