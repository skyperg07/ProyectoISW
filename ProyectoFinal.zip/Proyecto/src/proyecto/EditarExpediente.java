/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import static proyecto.AgregarExpediente.getConnection;

/**
 *
 * @author cesar-rodriguez
 */
public class EditarExpediente extends javax.swing.JFrame {
    
    
    String idExpediente;
    Color miColor = new Color(222, 205, 164);

    /**
     * Creates new form EditarExpediente
     */
    public EditarExpediente() {
        initComponents();
        this.setLocationRelativeTo(null);
        getContentPane().setBackground(miColor);
        setDefaultCloseOperation(EditarExpediente.DISPOSE_ON_CLOSE);
        llenarComboBoxPropietarios(jComboBox3);
        calle1.setEnabled(false);
        numero1.setEnabled(false);
        colonia1.setEnabled(false);
        estado1.setEnabled(false);
        municipio1.setEnabled(false);
        noLote1.setEnabled(false);
        superficie.setEnabled(false);
        fecha4.setEnabled(false);
        fecha5.setEnabled(false);
        fecha6.setEnabled(false);
        jButton2.setEnabled(false);
        llenarComboBoxMunicipio(municipio1);
        llenarComboBoxEstado(estado1);
        jPanel2.setBackground(miColor);
        jPanel5.setBackground(miColor);
        jPanel9.setBackground(miColor);
        jPanel7.setBackground(miColor);
        jPanel8.setBackground(miColor);
    }
    
    public void refresh() {
        this.dispose();          // Libera recursos
        EditarExpediente refresh = new EditarExpediente();
        refresh.setVisible(true);
}
    
    
        public boolean editarExpediente(String idExpediente, int idPropietario, String noLote, String superficie, String calle, String numero, String colonia, String municipio, String estado, java.sql.Date fechaCV, java.sql.Date fechaIO, java.sql.Date fechaFO) {
        String sql = "UPDATE expediente SET idPropietarios = ?, Numero_Lote = ?, Superficie = ?, Calle = ?, Numero = ?, Colonia = ?, Municipio = ?, Estado = ?, Fecha_compra_venta = ?, Inicio_de_obra = ?, Termino_de_obra = ? WHERE idExpediente = ?;";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, idPropietario + "");
            pstmt.setString(2, noLote.toUpperCase());
            pstmt.setString(3, superficie.toUpperCase());
            pstmt.setString(4, calle.toUpperCase());
            pstmt.setString(5, numero);
            pstmt.setString(6, colonia.toUpperCase());
            pstmt.setString(7, municipio.toUpperCase());
            pstmt.setString(8, estado.toUpperCase());
            pstmt.setString(9, fechaCV.toString());
            pstmt.setString(10, fechaIO.toString());
            pstmt.setString(11, fechaFO.toString());
            pstmt.setString(12, idExpediente);

            int filasInsertadas = pstmt.executeUpdate();
            if (filasInsertadas > 0) {
                //System.out.println("Expediente modificado correctamente");
                JOptionPane.showMessageDialog(null, "Expediente modificado correctamente");
                refresh();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }
        
        public void llenarComboBoxEstado(JComboBox<String> comboBox) {
        String consulta = "SELECT id_estado, nombre FROM estados";  // Modifica con tu tabla y columna

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery(consulta)) {
            
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione estado");
            while (rs.next()) {
               comboBox.addItem(rs.getString("id_estado") + " " + rs.getString("nombre")); // Agregar cada nombre al ComboBox 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
        
        public void llenarComboBoxMunicipio(JComboBox<String> comboBox) {
        String consulta = "SELECT id_municipio, nombre FROM municipios";  

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        

        try (ResultSet rs = pstmt.executeQuery()) {  // Ejecuta la consulta correctamente
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione municipio");

            while (rs.next()) {
                String municipio = rs.getString("id_municipio") + " " + 
                                    rs.getString("nombre");
                comboBox.addItem(municipio);  // Agrega cada expediente al ComboBox 
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }
    
    public int busquedaExpediente(String [] propietario){

        if(propietario.length== 3){
            return obtenerIdPropietario(propietario[0], propietario[1], propietario[2]);
        }else if(propietario.length == 4){
            String nombrePropietario = propietario[0] + " " + propietario[1];
            return obtenerIdPropietario(nombrePropietario, propietario[2], propietario[3]);
        }
        return -2;
    }
    
    public static int obtenerIdPropietario(String nombre, String apellidoPaterno, String apellidoMaterno) {
        
        // Consulta SQL para buscar el propietario
        String sql = "SELECT idPropietarios FROM propietarios WHERE Nombre = ? AND Paterno = ? AND Materno = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Asignar valores a los parámetros de la consulta
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellidoPaterno);
            pstmt.setString(3, apellidoMaterno);
            
            // Ejecutar la consulta
            ResultSet rs = pstmt.executeQuery();
            
            // Si hay un resultado, devolver el ID del propietario
            if (rs.next()) {
                return rs.getInt("idPropietarios");
            } else {
                return -1; // Retorna -1 si no se encuentra el propietario
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Retorna -1 en caso de error
        }
    }
    
    public void llenarComboBoxPropietarios(JComboBox<String> comboBox) {
        String consulta = "SELECT Nombre, Paterno, Materno FROM propietarios";  // Modifica con tu tabla y columna

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery(consulta)) {
            
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione propietario");
            while (rs.next()) {
               comboBox.addItem(rs.getString("Nombre") + " " + rs.getString("Paterno") + " "+ rs.getString("Materno")); // Agregar cada nombre al ComboBox 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void llenarComboBoxExpedientes(JComboBox<String> comboBox, int id) {
    String consulta = "SELECT idExpediente, Numero_Lote, Colonia, Calle, Numero, Municipio, Estado, Fecha_compra_venta FROM expediente WHERE idPropietarios = ?";  

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        
        pstmt.setInt(1, id);  // Asigna correctamente el ID

        try (ResultSet rs = pstmt.executeQuery()) {  // Ejecuta la consulta correctamente
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione expediente");

            while (rs.next()) {
                String expediente = "Folio: " + rs.getString("idExpediente") + "\n" + " " + 
                        "Numero de lote: " + rs.getString("Numero_Lote") + " " + 
                        "Colonia: " + rs.getString("Colonia") + " " + 
                        "Calle: " + rs.getString("Calle") + "\n" + 
                        "Numero: " + rs.getString("Numero") + " " + 
                        "Estado: " + rs.getString("Estado") + " " + 
                        "Municipio: " + rs.getString("Municipio") + "\n" +
                        "Fecha Compra-Venta: " + rs.getDate("Fecha_compra_venta");
                
                comboBox.addItem(expediente);  // Agrega cada expediente al ComboBox 
            }
            
             // Establecer tamaño fijo(Error solucionado pero buscar mejor opcion)
        Dimension fixedSize = new Dimension(150, 30);
        comboBox.setPreferredSize(fixedSize);
        comboBox.setMinimumSize(fixedSize);
        comboBox.setMaximumSize(fixedSize);

            comboBox.setRenderer(new MultiLineRenderer());
//            jPanel2.setBackground(miColor);
//            jPanel5.setBackground(miColor);
//            jPanel9.setBackground(miColor);
//            jPanel7.setBackground(miColor);
//            jPanel8.setBackground(miColor);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        
    }
}
    
    public void llenarCamposExpediente(String idExpediente) {
    String consulta = "SELECT Numero_Lote, Superficie, Calle, Numero, Colonia, Municipio, Estado, Fecha_Compra_Venta, Inicio_de_obra, Termino_de_obra FROM expediente WHERE idExpediente = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        
        pstmt.setString(1, idExpediente);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                noLote1.setText(rs.getString("Numero_Lote"));
                superficie.setText(String.valueOf(rs.getDouble("Superficie"))); // Verifica si es número
                calle1.setText(rs.getString("Calle"));
                numero1.setText(rs.getString("Numero"));
                colonia1.setText(rs.getString("Colonia"));
                //System.out.println(rs.getString("id _municipio"));
                municipio1.addItem(rs.getString("Municipio"));
                estado1.addItem(rs.getString("Estado"));
                municipio1.setSelectedItem(rs.getString("Municipio"));
                estado1.setSelectedItem(rs.getString("Estado"));

                // Manejo correcto de fechas
                java.sql.Date fechaCompra = rs.getDate("Fecha_Compra_Venta");
                java.sql.Date fechaInicio = rs.getDate("Inicio_de_obra");
                java.sql.Date fechaTermino = rs.getDate("Termino_de_obra");

                if (fechaCompra != null) fecha4.setDate(new java.util.Date(fechaCompra.getTime()));
                if (fechaInicio != null) fecha5.setDate(new java.util.Date(fechaInicio.getTime()));
                if (fechaTermino != null) fecha6.setDate(new java.util.Date(fechaTermino.getTime()));
                calle1.setEnabled(true);
                numero1.setEnabled(true);
                colonia1.setEnabled(true);
                estado1.setEnabled(true);
                municipio1.setEnabled(true);
                noLote1.setEnabled(true);
                superficie.setEnabled(true);
                fecha4.setEnabled(true);
                fecha5.setEnabled(true);
                fecha6.setEnabled(true);
                jButton2.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el expediente", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    
    
public int obtenerIdExpediente(String numeroLote, Double superficie, String calle, String numero, String colonia, String estado, String municipio, java.sql.Date fechaCV, java.sql.Date fechaIO, java.sql.Date fechaFO) {
    String consulta = "SELECT idExpediente FROM expediente WHERE Numero_Lote = ? AND Superficie = ? AND Calle = ? AND Numero = ? AND Colonia = ? AND Municipio = ? AND Estado = ? AND Fecha_Compra_Venta = ? AND Inicio_de_obra = ? AND Termino_de_obra = ?";
    int idExpediente = -1; // Valor predeterminado si no se encuentra el expediente

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {

        // Establecer los parámetros de la consulta
        pstmt.setString(1, numeroLote);
        pstmt.setDouble(2, superficie);
        pstmt.setString(3, calle);
        pstmt.setString(4, numero);
        pstmt.setString(5, colonia);
        pstmt.setString(6, estado);
        pstmt.setString(7, municipio);
        pstmt.setDate(8, fechaCV);
        pstmt.setDate(9, fechaIO);
        pstmt.setDate(10, fechaFO);

        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                // Si se encuentra el expediente, obtener el id
                idExpediente = rs.getInt("idExpediente");
            } else {
                // Si no se encuentra, mostrar mensaje
                JOptionPane.showMessageDialog(null, "No se encontró el expediente con los datos proporcionados", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener el ID del expediente: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    return idExpediente;
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        calle1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        numero1 = new javax.swing.JTextField();
        colonia1 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        estado1 = new javax.swing.JComboBox<>();
        municipio1 = new javax.swing.JComboBox<>();
        jPanel8 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        noLote1 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        fecha4 = new com.toedter.calendar.JDateChooser();
        fecha5 = new com.toedter.calendar.JDateChooser();
        fecha6 = new com.toedter.calendar.JDateChooser();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        superficie = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Editar expediente", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jPanel5.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Propietario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jComboBox3.setBackground(new java.awt.Color(0, 0, 0, 0));
        jComboBox3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox3, 0, 496, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jButton2.setBackground(new java.awt.Color(153, 255, 153));
        jButton2.setText("Editar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Ubicacion", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        calle1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                calle1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                calle1FocusLost(evt);
            }
        });
        calle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calle1ActionPerformed(evt);
            }
        });
        calle1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                calle1KeyTyped(evt);
            }
        });

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/la-carretera.png"))); // NOI18N

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/hashtag.png"))); // NOI18N

        numero1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                numero1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                numero1FocusLost(evt);
            }
        });
        numero1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero1ActionPerformed(evt);
            }
        });
        numero1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numero1KeyTyped(evt);
            }
        });

        colonia1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                colonia1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                colonia1FocusLost(evt);
            }
        });
        colonia1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                colonia1ActionPerformed(evt);
            }
        });
        colonia1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                colonia1KeyTyped(evt);
            }
        });

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ubicacion.png"))); // NOI18N

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ubicacion.png"))); // NOI18N

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ubicacion.png"))); // NOI18N

        estado1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                estado1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                estado1MousePressed(evt);
            }
        });

        municipio1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                municipio1MousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addComponent(jLabel13)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(numero1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(calle1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(colonia1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(municipio1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(estado1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(estado1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(municipio1)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel12)
                            .addComponent(calle1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(numero1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(colonia1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        jPanel8.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Informacion", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calendario.png"))); // NOI18N

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calendario.png"))); // NOI18N

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/calendario.png"))); // NOI18N

        noLote1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                noLote1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                noLote1FocusLost(evt);
            }
        });
        noLote1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noLote1ActionPerformed(evt);
            }
        });
        noLote1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                noLote1KeyTyped(evt);
            }
        });

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/hashtag.png"))); // NOI18N

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pantalla-completa.png"))); // NOI18N

        fecha5.setToolTipText("");

        jLabel25.setText("Fecha Compra-Venta");

        jLabel26.setText("Fecha Inicio Obra");

        jLabel27.setText("Fecha Fin Obra");

        jLabel28.setText("m2");

        superficie.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                superficieKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(noLote1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addComponent(jLabel21)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(fecha4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addGap(44, 44, 44)
                            .addComponent(jLabel25)
                            .addGap(14, 14, 14))))
                .addGap(13, 13, 13)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22)
                            .addComponent(jLabel20)
                            .addComponent(jLabel24))
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                                        .addComponent(jLabel27)
                                        .addGap(56, 56, 56))
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(fecha6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(fecha5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel8Layout.createSequentialGroup()
                                                .addComponent(superficie, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE)))))
                                .addGap(10, 10, 10))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel28)
                                .addContainerGap())))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel26)
                        .addGap(55, 55, 55))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel28)
                        .addGap(36, 36, 36)
                        .addComponent(fecha5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fecha6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addGap(36, 36, 36)
                        .addComponent(jLabel20)
                        .addGap(36, 36, 36)
                        .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel23)
                                    .addComponent(noLote1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(superficie)
                                .addGap(12, 12, 12)))
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(fecha4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(83, 83, 83))))
        );

        jPanel9.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Expediente", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jComboBox4.setBackground(new java.awt.Color(0, 0, 0, 0));
        jComboBox4.setToolTipText("");
        jComboBox4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jComboBox4.setPreferredSize(new java.awt.Dimension(496, 29));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jComboBox4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jButton1.setText("Modificar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 102, 102));
        jButton3.setText("Cancelar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        String [] propietarioDiv = jComboBox3.getSelectedItem().toString().split(" ");
        llenarComboBoxExpedientes(jComboBox4, busquedaExpediente(propietarioDiv));
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        //Mensaje al cumplir: "Expediente modificado correctamente"
        //Mensaje al no estar campo lleno:
               Date fechaCompraVenta = fecha4.getDate();
        Date fechaInicioObra = fecha5.getDate();
        Date fechaFinObra = fecha6.getDate();
        if(fechaCompraVenta != null && fechaInicioObra != null && fechaFinObra != null){
            long fechaCV = fechaCompraVenta.getTime();
        java.sql.Date fechaCV_sql = new java.sql.Date(fechaCV);
        
        
        long fechaIO = fechaInicioObra.getTime();
        java.sql.Date fechaIO_sql = new java.sql.Date(fechaIO);
        
        
        long fechaFO = fechaFinObra.getTime();
        java.sql.Date fechaFO_sql = new java.sql.Date(fechaFO);
        if(fechaCV_sql.before(fechaIO_sql) && fechaCV_sql.before(fechaFO_sql) && fechaIO_sql.before(fechaFO_sql)){
        
        String [] propietarioDiv = jComboBox3.getSelectedItem().toString().split(" ");
        //busquedaExpediente(propietarioDiv);
        //System.out.println(busquedaExpediente(propietarioDiv));
        
        if(!jComboBox3.getSelectedItem().equals("Seleccione propietario") && 
                !calle1.getText().isEmpty() && 
                !calle1.getText().equals("Calle") && 
                !numero1.getText().isEmpty() && 
                !numero1.getText().equals("Numero") && 
                !colonia1.getText().isEmpty() && 
                !colonia1.getText().equals("Colonia") && 
                !estado1.getSelectedItem().equals("Seleccione estado") && 
                !municipio1.getSelectedItem().equals("Seleccione municipio") && 
                !noLote1.getText().isEmpty() && 
                !noLote1.getText().equals("No de lote") && 
                !superficie.getText().isEmpty() && 
                fecha4 != null && 
                fecha5 != null && 
                fecha6 != null){
           if(editarExpediente(idExpediente, busquedaExpediente(propietarioDiv), noLote1.getText(), superficie.getText(), calle1.getText(), numero1.getText(), colonia1.getText(), estado1.getSelectedItem().toString(), municipio1.getSelectedItem().toString(), fechaCV_sql, fechaIO_sql, fechaFO_sql)) {
            //JOptionPane.showMessageDialog(null, "Expediente modificado correctamente");
            //limpiarCampos();
        }else{
            JOptionPane.showMessageDialog(null, "Error en la edicion del expediente");
        }
        }else{
            JOptionPane.showMessageDialog(null, "❌Todos los campos deben estar llenos");
        }
        }else{
            JOptionPane.showMessageDialog(null, "❌Fechas invalidas, verifique los campos");
        }
        }else{
            JOptionPane.showMessageDialog(null, "❌Todos los campos deben estar llenos");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void calle1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_calle1FocusGained
        if (calle1.getText().equals("Calle")) {
            calle1.setText("");
            calle1.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_calle1FocusGained

    private void calle1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_calle1FocusLost
        if (calle1.getText().isEmpty()) {
            calle1.setText("Calle");
            calle1.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_calle1FocusLost

    private void calle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calle1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_calle1ActionPerformed

    private void calle1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_calle1KeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9') && (c<'a' || c>'z') && (c<'A'||c>'Z') && c != ' ')evt.consume();
        
        //Limitacion de 16 caracteres
        if(calle1.getText().length() >= 16)evt.consume();
        
        if (Character.isLetterOrDigit(c) || evt.getKeyChar() == KeyEvent.VK_SPACE || evt.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
        //Codigo
        String cad = ("" + c).toUpperCase();
        c = cad.charAt(0);
        evt.setKeyChar(c);
    }
    }//GEN-LAST:event_calle1KeyTyped

    private void numero1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_numero1FocusGained
        if (numero1.getText().equals("Numero")) {
            numero1.setText("");
            numero1.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_numero1FocusGained

    private void numero1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_numero1FocusLost
        if (numero1.getText().isEmpty()) {
            numero1.setText("Numero");
            numero1.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_numero1FocusLost

    private void numero1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero1ActionPerformed
        
    }//GEN-LAST:event_numero1ActionPerformed

    private void numero1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numero1KeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
        
        //Limitacion de 8 caracteres
        if(numero1.getText().length() >= 8)evt.consume();
    }//GEN-LAST:event_numero1KeyTyped

    private void colonia1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_colonia1FocusGained
        if (colonia1.getText().equals("Colonia")) {
            colonia1.setText("");
            colonia1.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_colonia1FocusGained

    private void colonia1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_colonia1FocusLost
        if (colonia1.getText().isEmpty()) {
            colonia1.setText("Colonia");
            colonia1.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_colonia1FocusLost

    private void colonia1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_colonia1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_colonia1ActionPerformed

    private void colonia1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_colonia1KeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9') && (c<'a' || c>'z') && (c<'A'||c>'Z') && c != ' ')evt.consume();
        
        //Limitacion de 16 caracteres
        if(colonia1.getText().length() >= 16)evt.consume();
        
        if (Character.isLetterOrDigit(c) || evt.getKeyChar() == KeyEvent.VK_SPACE || evt.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
        //Codigo
        String cad = ("" + c).toUpperCase();
        c = cad.charAt(0);
        evt.setKeyChar(c);
    }
    }//GEN-LAST:event_colonia1KeyTyped

    private void noLote1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noLote1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_noLote1ActionPerformed

    private void noLote1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_noLote1KeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
        
        //Limitacion de 8 caracteres
        if(noLote1.getText().length() >= 5)evt.consume();
    }//GEN-LAST:event_noLote1KeyTyped

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
//        if(!jComboBox4.getSelectedItem().equals("Seleccione expediente") && jComboBox4.getSelectedItem().equals(null)){
//            String seleccionado = (String) jComboBox4.getSelectedItem();
//        System.out.println(seleccionado);
//        idExpediente = seleccionado.split(" ")[1];
//        System.out.println(idExpediente);
//        }
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //Aqui se llama al metodo para poder llenar los campos de la interfaz para realizar los actualizacion de los campos
        //llenarCamposExpediente(obtenerIdExpediente());
        //Mensaje por si solo oprime modificar "Seleccione propietario y expediente"
        if((jComboBox4.getSelectedItem().toString().equals("Seleccione expediente")) || (jComboBox3.getSelectedItem().toString().equals("Seleccione propietario"))){
            JOptionPane.showMessageDialog(null, "Seleccione propietario y/o expediente");
        }else{
            String [] expediente = jComboBox4.getSelectedItem().toString().split(" ");
            idExpediente = expediente[1];
            llenarCamposExpediente(idExpediente);
            fecha4.getDateEditor().getUiComponent().setEnabled(false);
            fecha5.getDateEditor().getUiComponent().setEnabled(false);
            fecha6.getDateEditor().getUiComponent().setEnabled(false);
        } jButton1.setEnabled(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void noLote1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_noLote1FocusGained
        // TODO add your handling code here:
        if (noLote1.getText().equals("No de lote")) {
            noLote1.setText("");
            noLote1.setForeground(Color.BLACK); // Color normal
    }
    }//GEN-LAST:event_noLote1FocusGained

    private void noLote1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_noLote1FocusLost
        // TODO add your handling code here:
        if (noLote1.getText().isEmpty()) {
            noLote1.setText("No de lote");
            noLote1.setForeground(Color.GRAY); // Color gris como pista
    }
    }//GEN-LAST:event_noLote1FocusLost

    private void superficieKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_superficieKeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
        
        //Limitacion de 8 caracteres
        if(superficie.getText().length() >= 8)evt.consume();
    }//GEN-LAST:event_superficieKeyTyped

    private void estado1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_estado1MouseClicked
        
    }//GEN-LAST:event_estado1MouseClicked

    private void estado1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_estado1MousePressed
        // TODO add your handling code here:
        llenarComboBoxEstado(estado1);
    }//GEN-LAST:event_estado1MousePressed

    private void municipio1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_municipio1MousePressed
        // TODO add your handling code here:
        llenarComboBoxMunicipio(municipio1);
    }//GEN-LAST:event_municipio1MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditarExpediente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditarExpediente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField calle1;
    private javax.swing.JTextField colonia1;
    private javax.swing.JComboBox<String> estado1;
    private com.toedter.calendar.JDateChooser fecha4;
    private com.toedter.calendar.JDateChooser fecha5;
    private com.toedter.calendar.JDateChooser fecha6;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JComboBox<String> municipio1;
    private javax.swing.JTextField noLote1;
    private javax.swing.JTextField numero1;
    private javax.swing.JTextField superficie;
    // End of variables declaration//GEN-END:variables
}
