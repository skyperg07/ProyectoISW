/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.net.URL;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import static proyecto.AgregarExpediente.getConnection;
import static proyecto.IniciarSesion.verificarCredenciales;

/**
 *
 * @author cesar-rodriguez
 */
public class EditarPropietario extends javax.swing.JFrame {

    String idPropietario;
    /**
     * Creates new form Propietario
     */
    public EditarPropietario() {
        initComponents();
        this.setLocationRelativeTo(null);
        genero.setVisible(false);
        ButtonGroup buttonGroup1 = new ButtonGroup();
        buttonGroup1.add(rbtnMasculino);
        buttonGroup1.add(rbtnFemenino);
        Color miColor = new Color(222, 205, 164);
        getContentPane().setBackground(miColor);
        setDefaultCloseOperation(RegistrarUsuario.DISPOSE_ON_CLOSE);
        llenarComboBoxPropietarios(jComboBox1);
        bloquearCampos();
        jPanel1.setBackground(miColor);
    }
    
    public void bloquearCampos(){
        nombre.setEditable(false);
        paterno.setEditable(false);
        materno.setEditable(false);
        correo.setEditable(false);
        numero.setEditable(false);
        rbtnMasculino.setEnabled(false);
        rbtnFemenino.setEnabled(false);
    }
    
    public void refresh(){
        this.dispose();          // Libera recursos
        EditarPropietario refresh = new EditarPropietario();
        refresh.setVisible(true);

    }
        
    public int busquedaExpediente(String [] propietario){

        if(propietario.length== 3){
            return obtenerIdPropietario(propietario[0], propietario[1], propietario[2]);
        }else if(propietario.length == 4){
            String nombrePropietario = propietario[0] + " " + propietario[1];
            return obtenerIdPropietario(nombrePropietario, propietario[2], propietario[3]);
        }
        return -2;
    }
    
    public static int obtenerIdPropietario(String nombre, String apellidoPaterno, String apellidoMaterno) {
        
        // Consulta SQL para buscar el propietario
        String sql = "SELECT idPropietarios FROM propietarios WHERE Nombre = ? AND Paterno = ? AND Materno = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Asignar valores a los parámetros de la consulta
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellidoPaterno);
            pstmt.setString(3, apellidoMaterno);
            
            // Ejecutar la consulta
            ResultSet rs = pstmt.executeQuery();
            
            // Si hay un resultado, devolver el ID del propietario
            if (rs.next()) {
                return rs.getInt("idPropietarios");
            } else {
                return -1; // Retorna -1 si no se encuentra el propietario
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Retorna -1 en caso de error
        }
    }
    
    
    public void llenarComboBoxPropietarios(JComboBox<String> comboBox) {
        String consulta = "SELECT Nombre, Paterno, Materno FROM propietarios";  // Modifica con tu tabla y columna

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(consulta);
             ResultSet rs = pstmt.executeQuery(consulta)) {
            
            comboBox.removeAllItems(); // Limpiar ComboBox antes de agregar nuevos datos
            comboBox.addItem("Seleccione propietario");
            while (rs.next()) {
               comboBox.addItem(rs.getString("Nombre") + " " + rs.getString("Paterno") + " "+ rs.getString("Materno")); // Agregar cada nombre al ComboBox 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void llenarCamposPropietario(String idPropietario) {
    String consulta = "SELECT idGenero, Nombre, Paterno, Materno, Correo, Num FROM propietarios WHERE idPropietarios = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        
        pstmt.setString(1, idPropietario);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                genero.setText(rs.getString("IdGenero"));
                if(genero.getText().equals("1")){
                    rbtnMasculino.setSelected(true);
                }else{
                    rbtnFemenino.setSelected(true);
                }
                nombre.setText(rs.getString("Nombre")); // Verifica si es número
                paterno.setText(rs.getString("Paterno"));
                materno.setText(rs.getString("Materno"));
                correo.setText(rs.getString("Correo"));
                numero.setText(rs.getString("Num"));

                
            } 
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    
    private static final String URL = "jdbc:mysql://localhost:3306/proyecto";
    private static final String USER = "root";
    private static final String PASSWORD = "Goli@t2014";
    
    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    
    private void btnValidarActionPerformed(java.awt.event.ActionEvent evt) {
        if (rbtnMasculino.isSelected()) {
            
        }else if (rbtnFemenino.isSelected()) {
        
        }
    }
    public void editarPropietario(String genero, String nombre, String paterno, String materno, String correo, String numero, String idPropietario) {
        String sql = "UPDATE propietarios SET idGenero =?, Nombre=?, Paterno=?, Materno=?, Correo=?, Num=? WHERE idPropietarios = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, genero+"");
            pstmt.setString(2, nombre);
            pstmt.setString(3, paterno);
            pstmt.setString(4, materno);
            pstmt.setString(5, correo);
            pstmt.setString(6, numero);
            pstmt.setString(7, idPropietario);

            int filasInsertadas = pstmt.executeUpdate();
            if (filasInsertadas > 0) {
                JOptionPane.showMessageDialog(null, "Propietario modificado correctamente");
                refresh();
                bloquearCampos();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        paterno = new javax.swing.JTextField();
        materno = new javax.swing.JTextField();
        correo = new javax.swing.JTextField();
        numero = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        rbtnMasculino = new javax.swing.JRadioButton();
        rbtnFemenino = new javax.swing.JRadioButton();
        genero = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Editar Propietario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/propietarioGrande.png"))); // NOI18N

        nombre.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                nombreFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                nombreFocusLost(evt);
            }
        });
        nombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nombreKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombreKeyTyped(evt);
            }
        });

        paterno.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                paternoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                paternoFocusLost(evt);
            }
        });
        paterno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paternoActionPerformed(evt);
            }
        });
        paterno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                paternoKeyTyped(evt);
            }
        });

        materno.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                maternoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                maternoFocusLost(evt);
            }
        });
        materno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                maternoKeyTyped(evt);
            }
        });

        correo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                correoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                correoFocusLost(evt);
            }
        });
        correo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                correoActionPerformed(evt);
            }
        });

        numero.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                numeroFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                numeroFocusLost(evt);
            }
        });
        numero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numeroKeyTyped(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(153, 255, 153));
        jButton1.setText("Editar propietario");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Genero");

        rbtnMasculino.setText("Hombre");
        rbtnMasculino.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbtnMasculinoMouseClicked(evt);
            }
        });
        rbtnMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnMasculinoActionPerformed(evt);
            }
        });

        rbtnFemenino.setText("Mujer");
        rbtnFemenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnFemeninoActionPerformed(evt);
            }
        });

        genero.setEditable(false);
        genero.setBackground(new java.awt.Color(0, 0, 0, 0));

        jButton2.setBackground(new java.awt.Color(255, 102, 102));
        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton3.setText("Editar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(nombre, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
                    .addComponent(paterno, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
                    .addComponent(materno, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
                    .addComponent(correo, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
                    .addComponent(numero, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(rbtnMasculino)
                        .addGap(18, 18, 18)
                        .addComponent(rbtnFemenino)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 156, Short.MAX_VALUE)
                .addComponent(genero, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(122, 122, 122)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(paterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(materno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addGap(2, 2, 2)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rbtnMasculino)
                            .addComponent(rbtnFemenino))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(correo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(genero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(23, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void paternoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paternoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paternoActionPerformed

    private void correoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_correoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_correoActionPerformed

    private void rbtnMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnMasculinoActionPerformed
        genero.setText("1");
    }//GEN-LAST:event_rbtnMasculinoActionPerformed

    private void rbtnFemeninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnFemeninoActionPerformed
        genero.setText("2");
    }//GEN-LAST:event_rbtnFemeninoActionPerformed

    private void nombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreKeyPressed
        
    }//GEN-LAST:event_nombreKeyPressed

    private void nombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreKeyTyped
        char c = evt.getKeyChar();
        if((c<'a' || c>'z') && (c<'A'||c>'Z') && c != ' ')evt.consume();
        
        //Limitacion de 16 caracteres
        if(nombre.getText().length() >= 16)evt.consume();
        if (Character.isLetterOrDigit(c) || evt.getKeyChar() == KeyEvent.VK_SPACE || evt.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
        //Codigo
        String cad = ("" + c).toUpperCase();
        c = cad.charAt(0);
        evt.setKeyChar(c);
    }
    }//GEN-LAST:event_nombreKeyTyped

    private void paternoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_paternoKeyTyped
        char c = evt.getKeyChar();
        if((c<'a' || c>'z') && (c<'A'||c>'Z') && c != ' ')evt.consume();
        
        //Limitacion de 16 caracteres
        if(paterno.getText().length() >= 16)evt.consume();
        
        if (Character.isLetterOrDigit(c) || evt.getKeyChar() == KeyEvent.VK_SPACE || evt.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
        //Codigo
        String cad = ("" + c).toUpperCase();
        c = cad.charAt(0);
        evt.setKeyChar(c);
    }
    }//GEN-LAST:event_paternoKeyTyped

    private void maternoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_maternoKeyTyped
        char c = evt.getKeyChar();
        if((c<'a' || c>'z') && (c<'A'||c>'Z') && c != ' ')evt.consume();
        
        //Limitacion de 16 caracteres
        if(materno.getText().length() >= 16)evt.consume();
        
        if (Character.isLetterOrDigit(c) || evt.getKeyChar() == KeyEvent.VK_SPACE || evt.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
        //Codigo
        String cad = ("" + c).toUpperCase();
        c = cad.charAt(0);
        evt.setKeyChar(c);
    }
    }//GEN-LAST:event_maternoKeyTyped

    private void nombreFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_nombreFocusGained
        
    }//GEN-LAST:event_nombreFocusGained

    private void nombreFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_nombreFocusLost
       
    }//GEN-LAST:event_nombreFocusLost

    private void paternoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_paternoFocusGained
        
    }//GEN-LAST:event_paternoFocusGained

    private void paternoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_paternoFocusLost
       
    }//GEN-LAST:event_paternoFocusLost

    private void maternoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_maternoFocusGained
       
    }//GEN-LAST:event_maternoFocusGained

    private void maternoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_maternoFocusLost
        
    }//GEN-LAST:event_maternoFocusLost

    private void correoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_correoFocusGained
       
    }//GEN-LAST:event_correoFocusGained

    private void correoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_correoFocusLost
       
    }//GEN-LAST:event_correoFocusLost

    private void numeroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_numeroFocusGained
       
    }//GEN-LAST:event_numeroFocusGained

    private void numeroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_numeroFocusLost
        
    }//GEN-LAST:event_numeroFocusLost

    private void numeroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numeroKeyTyped
        char c = evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
        
        //Limitacion de 16 caracteres
        if(numero.getText().length() >= 10)evt.consume();
    }//GEN-LAST:event_numeroKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    
        if (!nombre.getText().isEmpty() &&
            !paterno.getText().isEmpty() &&
            !materno.getText().isEmpty() &&
            !correo.getText().isEmpty() &&
            !numero.getText().isEmpty() &&
            !genero.getText().isEmpty()) {
    
    editarPropietario(genero.getText(), nombre.getText(), paterno.getText(), materno.getText(), correo.getText(), numero.getText(), idPropietario);

} else {
    JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos");
}
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Llamar metodo para llenar campos
        if(!jComboBox1.getSelectedItem().toString().equals("Seleccione propietario")){
            String [] nombrePropietario = jComboBox1.getSelectedItem().toString().split(" ");
        idPropietario = busquedaExpediente(nombrePropietario) + "";
        llenarCamposPropietario(idPropietario);
        rbtnMasculino.setEnabled(true);
        rbtnFemenino.setEnabled(true);
        nombre.setEditable(true);
        paterno.setEditable(true);
        materno.setEditable(true);
        correo.setEditable(true);
        numero.setEditable(true);
        }else{
            JOptionPane.showMessageDialog(null, "Seleccione un propietario");
        }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void rbtnMasculinoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbtnMasculinoMouseClicked
       
    }//GEN-LAST:event_rbtnMasculinoMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditarPropietario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditarPropietario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditarPropietario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditarPropietario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditarPropietario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField correo;
    private javax.swing.JTextField genero;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField materno;
    private javax.swing.JTextField nombre;
    private javax.swing.JTextField numero;
    private javax.swing.JTextField paterno;
    private javax.swing.JRadioButton rbtnFemenino;
    private javax.swing.JRadioButton rbtnMasculino;
    // End of variables declaration//GEN-END:variables
    private int genero1;
}
